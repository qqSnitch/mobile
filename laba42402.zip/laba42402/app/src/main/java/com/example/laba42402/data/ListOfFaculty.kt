package com.example.laba42402.data

class ListOfFaculty (
    var items:MutableList<Faculty> = mutableListOf()
)