package com.example.laba42402

object MyConsts{
    val TAG = "com.example.student_base.log"
}
enum class NamesOfFragment {
    FACULTY,GROUP,STUDENT
}