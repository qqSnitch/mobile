package com.example.laba42402.data

class ListOfGroup (
    var items:MutableList<Group> = mutableListOf()
)