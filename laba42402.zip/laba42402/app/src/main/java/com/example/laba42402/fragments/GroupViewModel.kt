package com.example.laba42402.fragments

import androidx.lifecycle.ViewModel

class GroupViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}