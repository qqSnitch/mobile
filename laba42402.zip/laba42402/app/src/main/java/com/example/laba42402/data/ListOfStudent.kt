package com.example.laba42402.data

class ListOfStudent (
    var items:MutableList<Student> = mutableListOf()
)