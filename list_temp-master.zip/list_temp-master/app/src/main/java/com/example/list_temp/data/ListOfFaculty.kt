package com.example.list_temp.data

data class ListOfFaculty(
    var items : MutableList<Faculty> = mutableListOf()
)
