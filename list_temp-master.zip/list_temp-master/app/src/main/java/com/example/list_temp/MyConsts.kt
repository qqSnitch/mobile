package com.example.list_temp

object MyConsts {
    val TAG = "com.example.list_temp.log"
}

enum class NamesOfFragment {
        FACULTY, GROUP, STUDENT
}
