package com.example.list_temp.data

data class ListOfGroup(
    var items : MutableList<Group> = mutableListOf()
)
