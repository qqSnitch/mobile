package com.example.list_temp.data

data class ListOfStudent(
    var items : MutableList<Student> = mutableListOf()
)
